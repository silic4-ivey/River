import java.net.*;
import java.io.*;

public class RiverClient {
	private static RiverClient instance;
	private final int PORT_NUM = 3333;
	private Socket s;  
	private DataInputStream din;  
	private DataOutputStream dout;  
	private BufferedReader br;
	
	private RiverClient() {
		try {
			s=new Socket("localhost",PORT_NUM); 
			din=new DataInputStream(s.getInputStream());  
			dout=new DataOutputStream(s.getOutputStream());  
			br=new BufferedReader(new InputStreamReader(System.in)); 
		}catch(IOException io) {
			System.out.println("Failed to initialize client");
			
		}
	}
	
	public static RiverClient getInstance() {
		
		if(instance==null) {
			instance = new RiverClient();
		}
		return instance;
		
	}
	
	public void writeTo() {
		try {

			String str="",str2="";  
			while(!str.equals("stop")){  
				str=br.readLine();  
				dout.writeUTF("CHARON 1: " + str);  
				dout.flush();  
				str2=din.readUTF();  
				System.out.println(str2);  
			} 
		}catch(IOException io) {
			System.out.println("Failed to write");
			
		}
	}
	
	public void closeAccess() {
		try {
			dout.close();  
			s.close();  
		}catch(IOException io) {
			System.out.println("Failed to close access");
		
		}
	}
}
